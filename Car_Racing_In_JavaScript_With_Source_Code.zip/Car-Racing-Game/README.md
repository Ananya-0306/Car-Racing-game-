# Car-Racing-Game
 The racing video game genre is the genre of video games, either in the first-person or third-person perspective, in which the player partakes in a racing competition with any type of land, water, air or space vehicles
 This game is created using HTML5, CSS3 and VanillaJavasript, including high end CSS animation created using Javascript functions.
 Code of this can be useful for begginers to CSS,Javascript animation.
